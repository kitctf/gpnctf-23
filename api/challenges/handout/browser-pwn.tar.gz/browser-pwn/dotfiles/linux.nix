{ config, pkgs, lib, ... }: {
  home.username = "hacker";
  home.homeDirectory = "/home/hacker";

  home.packages = with pkgs; [
    # r/unixporn essentials 
    neofetch
    btop
    nnn 
    conky
    vim

    # "work"
    metasploit
    ffuf
    monero-cli
    tor
    wayvnc

    # watching anime
    aria2
    firefox
    playerctl
    mpv
  ];

  programs.wofi = {
    enable = true;
    style = ''
    window {
      margin: 0px;
      border: 1px solid #bd93f9;
      background-color: #282a36;
    }

    #input {
      margin: 5px;
      border: none;
      color: #f8f8f2;
      background-color: #44475a;
    }

    #inner-box {
      margin: 5px;
      border: none;
      background-color: #282a36;
    }

    #outer-box {
      margin: 5px;
      border: none;
      background-color: #282a36;
    }

    #scroll {
      margin: 0px;
      border: none;
    }

    #text {
      margin: 5px;
      border: none;
      color: #f8f8f2;
    }

    #entry:selected {
      background-color: #44475a;
    }

    * {
      font-family: "Fira Mono";
      font-size: 25px;
    }
    '';
  };

  home.file.".dashboard".text = ''
use_xft yes
xftfont 123:size=8
xftalpha 0.1
update_interval 1
total_run_times 0

own_window yes
own_window_type normal
own_window_transparent yes
own_window_hints undecorated,below,sticky,skip_taskbar,skip_pager
own_window_colour 000000
own_window_argb_visual yes
own_window_argb_value 0

double_buffer yes
minimum_size 25 2
maximum_width 350
draw_shades no
draw_outline no
draw_borders no
draw_graph_borders no
default_color white
default_shade_color red
default_outline_color green
alignment top_left
gap_x 30
gap_y 30
no_buffers yes
uppercase no
cpu_avg_samples 2
net_avg_samples 1
override_utf8_locale yes
use_spacer yes


minimum_size 0 0

TEXT
''${color grey}Info:$color ''${scroll 32 Conky $conky_version - $sysname $nodename $kernel $machine}
$hr
''${color grey}Uptime:$color $uptime
''${color grey}Frequency (in MHz):$color $freq
''${color grey}Frequency (in GHz):$color $freq_g
''${color grey}Now playing:''${color} ''${execp playerctl -s metadata title}
''${color grey}RAM Usage:$color $mem/$memmax - $memperc% ''${membar 4}
''${color grey}Swap Usage:$color $swap/$swapmax - $swapperc% ''${swapbar 4}
$hr
''${color grey}File systems:
/ $color''${fs_used /}/''${fs_size /} ''${fs_bar 6 /}
''${color grey}Networking:
Up:$color ''${upspeed} ''${color grey} - Down:$color ''${downspeed}
$hr
  '';

  wayland.windowManager.sway = {
    enable = true;
    config.keybindings = let
      modifier = config.wayland.windowManager.sway.config.modifier;
    in lib.mkOptionDefault {
      "${modifier}+Return" = "exec ${pkgs.foot}/bin/foot";
      "${modifier}+Shift+q" = "kill";
      "${modifier}+d" = "exec ${pkgs.wofi}/bin/wofi --show drun";
    };
    extraConfig = ''
      default_border pixel 0
      output "*" background /home/hacker/dotfiles/wallpaper.png fill
      exec ${pkgs.conky}/bin/conky -qc /home/hacker/.dashboard

      # These things are there to make local challenge debugging easier, they should :tm: not influence the solve
      exec /server # the adminbot ui
      output HEADLESS-1 pos 0 0 res 1920x1080
      exec wayvnc 0.0.0.0 5910
    '';
  };

  programs.git = {
    enable = true;
    userName = "Real hacker";
    userEmail = "r3alhacker@example.com";
  };

  home.stateVersion = "25.05";
}
