#!/usr/bin/env bash
echo "Starting headless sway"
export XDG_RUNTIME_DIR=/run/user/1001
export XDG_SEAT=seat0
export XDG_SESSION_CLASS=user
export XDG_SESSION_ID=1
export XDG_SESSION_TYPE=wayland
export MOZ_ENABLE_WAYLAND=1
export WLR_BACKENDS=headless
export XDG_DATA_DIRS=/home/hacker/.nix-profile/share

dbus-run-session sh -c 'pulseaudio --start --exit-idle-time=-1 --load="module-null-sink sink_name=DummySink" && sway'
