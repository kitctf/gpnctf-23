package main

import (
	"fmt"
	"log"
	"net/http"
	"os/exec"
	"regexp"
	"strings"
)

var (
	latestURL string
	urlRegex = regexp.MustCompile(`^[a-zA-Z0-9./]+$`)
)

func main() {
	http.HandleFunc("/", handleForm)
	http.HandleFunc("/redirect", handleRedirect)

	port := "8080"
	fmt.Printf("Server starting on http://localhost:%s\n", port)
	log.Fatal(http.ListenAndServe(":"+port, nil))
}

func handleForm(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		html := `<!DOCTYPE html>
<html>
<head>
    <title>Hack the hackers</title>
</head>
<body>
    <h1>show me your cool 1-click exploit</h1>
    <form method="POST" action="/">
        <label for="url">Enter URL:</label><br>
        <input type="text" id="url" name="url" required style="width: 400px; padding: 5px;" placeholder="example.com/test"><br><br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>`
		w.Header().Set("Content-Type", "text/html")
		w.Write([]byte(html))
	} else if r.Method == "POST" {
		r.ParseForm()
		url := strings.TrimSpace(r.FormValue("url"))
		
		if url == "" {
			http.Error(w, "URL is required", http.StatusBadRequest)
			return
		}

		if !urlRegex.MatchString(url) {
			http.Error(w, "Invalid URL format. Only alphanumeric characters, dots, and slashes are allowed.", http.StatusBadRequest)
			return
		}

		latestURL = url

		go func() {
			cmd := exec.Command("firefox", "http://localhost:8080/redirect")
			err := cmd.Start()
			if err != nil {
				log.Printf("Failed to start Firefox: %v", err)
			}
		}()

		successHTML := fmt.Sprintf(`<!DOCTYPE html>
<html>
<head>
    <title>Hack the hackers</title>
</head>
<body>
    <h1>URL Submitted Successfully</h1>
</body>
</html>`)
		
		w.Header().Set("Content-Type", "text/html")
		w.Write([]byte(successHTML))
	} else {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
	}
}

func handleRedirect(w http.ResponseWriter, r *http.Request) {
	url := latestURL

	if url == "" {
		http.Error(w, "No URL has been submitted yet", http.StatusNotFound)
		return
	}

	url = "http://" + url

	http.Redirect(w, r, url, http.StatusFound)
}
