" init.vim

autocmd VimEnter * call ReadFlagAndSave()

function! ReadFlagAndSave()
    " Read the contents of /flag into the current buffer
    execute '0r /flag'

    " Save the buffer to its current file or create a new file if unnamed
    write

    LazyGitCurrentFile

    call timer_start(500, "NavigateLazyGit")
endfunction

function! NavigateLazyGit(id)
    call feedkeys("\<Space>cHi\<CR>\<CR>")

    call timer_start(500, "ExitLazyGit")
endfunction

function! ExitLazyGit(id)
    call feedkeys("\<CR>q")

    quit
    write
    quit
endfunction
